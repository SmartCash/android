package com.example.walletsmart;

import java.util.Date;

public class Transaction {
    private String hash;
    private Date timestamp;
    private Integer amout;
    private String direction;
    private String toAddress;
    private Boolean isPending;
    private Integer blockindex;
    private Boolean isNew;
    private Boolean isConfirmed;
    private Date orderData;

    public Transaction(String hash, Date timestamp, Integer amout, String direction, String toAddress, Boolean isPending, Integer blockindex, Boolean isNew, Boolean isConfirmed, Date orderData) {
        this.hash = hash;
        this.timestamp = timestamp;
        this.amout = amout;
        this.direction = direction;
        this.toAddress = toAddress;
        this.isPending = isPending;
        this.blockindex = blockindex;
        this.isNew = isNew;
        this.isConfirmed = isConfirmed;
        this.orderData = orderData;
    }
}
