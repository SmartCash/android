package com.example.walletsmart;

import retrofit2.Call;
import retrofit2.http.GET;

public interface UserService {

    @GET("getUserData.json")
    Call getUser();
}
