package com.example.walletsmart;

import java.util.Date;

public class User {
    private String password;
    private String confirmPassword;
    private String recoveryKey;
    private Integer notifications;
    private Date lastLoginDate;
    private String termsVersion;
    private Boolean is2FAEnabled;
    private Integer userId;
    private String firstName;
    private String lastName;
    private String username;
    private String email;
    private String facebookId;
    private String countryCode;
    private Wallet[] wallet;

    public User(String password, String confirmPassword, String recoveryKey, Integer notifications, Date lastLoginDate, String termsVersion, Boolean is2FAEnabled, Integer userId, String firstName, String lastName, String username, String email, String facebookId, String countryCode, Wallet[] wallet) {
        this.password = password;
        this.confirmPassword = confirmPassword;
        this.recoveryKey = recoveryKey;
        this.notifications = notifications;
        this.lastLoginDate = lastLoginDate;
        this.termsVersion = termsVersion;
        this.is2FAEnabled = is2FAEnabled;
        this.userId = userId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.email = email;
        this.facebookId = facebookId;
        this.countryCode = countryCode;
        this.wallet = wallet;
    }
}

