package com.example.walletsmart;

public class Wallet {
    private Integer walletId;
    private String displayName;
    private String address;
    private String qrCode;
    private Double balance;
    private Double totalSent;
    private Double totalReceived;
    private Integer position;
    private Boolean isRewards;
    private Boolean isVault;
    private Boolean isScheduled;
    private Integer cardId;
    private Transaction[] transactions;

    public Wallet(Integer walletId, String displayName, String address, String qrCode, Double balance, Double totalSent, Double totalReceived, Integer position, Boolean isRewards, Boolean isVault, Boolean isScheduled, Integer cardId, Transaction[] transactions) {
        this.walletId = walletId;
        this.displayName = displayName;
        this.address = address;
        this.qrCode = qrCode;
        this.balance = balance;
        this.totalSent = totalSent;
        this.totalReceived = totalReceived;
        this.position = position;
        this.isRewards = isRewards;
        this.isVault = isVault;
        this.isScheduled = isScheduled;
        this.cardId = cardId;
        this.transactions = transactions;
    }
}
