package com.example.walletsmart;

import retrofit2.Retrofit;
import retrofit2.converter.jackson.JacksonConverterFactory;

public class RetrofitConfig {

    public RetrofitConfig() {
        new Retrofit.Builder()
                .baseUrl("https://github.com/filippee2/smartCashData/blob/master/")
                .addConverterFactory(JacksonConverterFactory.create())
                .build();
    }

}
